<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - HYPOT</title>
    <link rel="stylesheet" href="../style/reset.css">
    <link rel="stylesheet" href="../style/estilophp.css">
</head>
<body>
    <header>
        <h2>funçÃo - hypot</h2>
    </header>
    <main>
        <div class="box">
            <p class="texto">A função hypot() é utilizada para calcular a hipotenusa entre dois catetos de um triângulo retângulo.</p>
            <hr>
            <p class="sint">hypot(c1,c2)</p>
            <hr>
            <form method="get">
                <label for="c1j">Insira o cateto 1</label><br>
                <input id="c1j" name="c1" type="number"><br>
                <label for="c2j">Insira o cateto 2</label><br>
                <input id="c2j" name="c2" type="number"><br>
                <input type="submit" value="Calcular">
            </form>
            <hr>
            <?php
                if(isset($_GET["c1"]) && isset($_GET["c2"])){
                    $c1 = $_GET["c1"];
                    $c2 = $_GET["c2"];
                    
                    echo"<p> A hipotenusa é ", hypot($c1, $c2), "</p>";
                }else{
                    echo"Por favor, insira um número";
                }
            ?>
            <br>
            <a href="..//index.html"><<</a>
        </div>
    </main>
</body>
</html>