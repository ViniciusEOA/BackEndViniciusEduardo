<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - SQRT</title>
    <link rel="stylesheet" href="../style/reset.css">
    <link rel="stylesheet" href="../style/estilophp.css">
</head>
<body>
    <header>
        <h2>funçÃo - sqrt</h2>
    </header>
    <main>
        <div class="box">
            <p class="texto">A função sqrt() é utilizada para calcular a raiz quadrada de um número </p>
            <hr>
            <p class="sint">sqrt(num)</p>
            <hr>
            <form method="get">
                <label for="numj">Insira o número</label><br>
                <input id="numj" name="num" type="number"><br>
                <input type="submit" value="Calcular">
            </form>
            <hr>
            <?php
                if(isset($_GET["num"])){
                    $num = $_GET["num"];
                    
                    echo"<p> A raiz quadrada de ",$num, " é ", sqrt($num), "</p>";
                }else{
                    echo"Por favor, insira um número";
                }
            ?>
            <br>
            <a href="..//index.html"><<</a>
        </div>
    </main>
</body>
</html>