<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - SIN</title>
    <link rel="stylesheet" href="../style/reset.css">
    <link rel="stylesheet" href="../style/estilophp.css">
</head>
<body>
    <header>
        <h2>funçÃo - sin</h2>
    </header>
    <main>
        <div class="box">
            <p class="texto">A função sin() é utilizada para calcular o seno de um ângulo. </p>
            <hr>
            <p class="sint">sin(angulo)</p>
            <hr>
            <form method="get">
                <label for="anguloj">Insira o ângulo</label><br>
                <input id="anguloj" name="angulo" type="float"><br>
                <input type="submit" value="Calcular">
            </form>
            <hr>
            <?php
                if(isset($_GET["angulo"])){
                    $angulo = $_GET["angulo"];
                    
                    echo"<p> O seno do ângulo é ", sin($angulo), "</p>";
                }else{
                    echo"Por favor, insira um número";
                }
            ?>
            <br>
            <a href="..//index.html"><<</a>
        </div>
    </main>
</body>
</html>