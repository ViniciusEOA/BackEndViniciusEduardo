<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - BASE_CONVERT</title>
    <link rel="stylesheet" href="../style/reset.css">
    <link rel="stylesheet" href="../style/estilophp.css">
</head>
<body>
    <header>
        <h2>funçÃo - bAse_conVert</h2>
    </header>
    <main>
        <div class="box">
            <p class="texto">A função base_convert() é utilizada para converter um número de uma base para outra, como por exemplo para decimal, hexadecimal, etc. </p>
            <hr>
            <p class="sint">base_convert(numero,baseog,basetf)</p>
            <hr>
            <form method="get">
                <label for="numeroj">Insira o número</label><br>
                <input id="numeroj" name="numero" type="string"><br>
                <label for="baseogj">Insira a base atual</label><br>
                <!-- <input id="baseogj" name="baseog" type="int"><br> -->
                <select name="baseog" id="baseogj">
                    <option value="2">Binário</option>
                    <option value="8">Octal</option>
                    <option value="10">Decimal</option>
                    <option value="16">Hexadecimal</option>
                </select><br>
                <label for="basetfj">Insira a base que será convertida</label><br>
                <select name="basetf" id="basetfj">
                    <option value="2">Binário</option>
                    <option value="8">Octal</option>
                    <option value="10">Decimal</option>
                    <option value="16">Hexadecimal</option>
                </select><br>
                <!--<input id="basetfj" name="basetf" type="int"><br>-->
                <input type="submit" value="Calcular">
            </form>
            <hr>
            <?php
                if(isset($_GET["numero"]) && isset($_GET["baseog"]) && isset($_GET["basetf"])){
                    $numero = $_GET["numero"];
                    $baseog = $_GET["baseog"];
                    $basetf = $_GET["basetf"];
                    
                    echo"<p> O resultado é ", base_convert($numero, $baseog, $basetf), "</p>";
                }else{
                    echo"Por favor, insira um número";
                }
            ?>
            <br>
            <a href="..//index.html"><<</a>
        </div>
    </main>
</body>
</html>