<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - MIN</title>
    <link rel="stylesheet" href="../style/reset.css">
    <link rel="stylesheet" href="../style/estilophp.css">
</head>
<body>
    <header>
        <h2>funçÃo - min</h2>
    </header>
    <main>
        <div class="box">
            <p class="texto"> A função min() é utilizada para encontrar o menor número de um conjunto.</p>
            <hr>
            <p class="sint">min(v1, v2, v3 ...)</p>
            <hr>
            <form method="get">
                <label for="v1j">Insira o valor 1</label><br>
                <input id="v1j" name="v1" type="number"><br>
                <label for="v2j">Insira o valor 2</label><br>
                <input id="v2j" name="v2" type="number"><br>
                <label for="v3j">Insira o valor 3</label><br>
                <input id="v3j" name="v3" type="number"><br>
                <input type="submit" value="Calcular">
            </form>
            <hr>
            <?php
                if(isset($_GET["v1"]) && isset($_GET["v2"]) && isset($_GET["v3"])){
                    $v1 = $_GET["v1"];
                    $v2 = $_GET["v2"];
                    $v3 = $_GET["v3"];
                    
                    echo"<p> O valor minimo é ", min($v1, $v2, $v3), "</p>";
                }else{
                    echo"Por favor, insira um número";
                }
            ?>
            <br>
            <a href="..//index.html"><<</a>
        </div>
    </main>
</body>
</html>