<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - HYPOT</title>
    <link rel="stylesheet" href="../style/reset.css">
    <link rel="stylesheet" href="../style/estilophp.css">
</head>
<body>
    <header>
        <h2>funçÃo - hypot</h2>
    </header>
    <main>
        <div class="box">
            <p class="texto">A função hypot() é utilizada para calcular a hipotenusa entre dois catetos de um triângulo retângulo.</p>
            <hr>
            <p class="sint">hypot(c1,c2)</p>
            <hr>
            <p class="ins">Insira o número</p>
        </div>
    </main>
</body>
</html>