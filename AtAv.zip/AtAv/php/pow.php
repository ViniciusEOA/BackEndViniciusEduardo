<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - POW</title>
    <link rel="stylesheet" href="../style/reset.css">
    <link rel="stylesheet" href="../style/estilophp.css">
</head>
<body>
    <header>
        <h2>funçÃo - pow</h2>
    </header>
    <main>
        <div class="box">
            <p class="texto"> A função pow() é utilizada para calcular a potência de um número.</p>
            <hr>
            <p class="sint">pow(base, expoente)</p>
            <hr>
            <p class="ins">Insira o número</p>
        </div>
    </main>
</body>
</html>