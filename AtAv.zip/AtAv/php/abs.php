<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - ABS</title>
    <link rel="stylesheet" href="../style/reset.css">
    <link rel="stylesheet" href="../style/estilophp.css">
</head>
<body>
    <header>
        <h2>funçÃo - Abs</h2>
    </header>
    <main>
        <div class="box">
            <p class="texto">A função abs() é utilizada para calcular o valor absoluto de um número, ou seja, o seu valor sem considerar o seu sinal. Ela retorna o valor positivo do número fornecido como argumento. Por exemplo, se o número fornecido for positivo, o resultado será o próprio número. Se o número fornecido for negativo, o resultado será o seu equivalente positivo.</p>
            <hr>
            <p class="sint">abs(num)</p>
            <hr>
            <p class="ins">Insira o número</p>
        </div>
    </main>
</body>
</html>