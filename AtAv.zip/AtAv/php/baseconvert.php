<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - BASE_CONVERT</title>
    <link rel="stylesheet" href="../style/reset.css">
    <link rel="stylesheet" href="../style/estilophp.css">
</head>
<body>
    <header>
        <h2>funçÃo - bAse_conVert</h2>
    </header>
    <main>
        <div class="box">
            <p class="texto">A função base_convert() é utilizada para converter um número de uma base para outra, como por exemplo para decimal, hexadecimal, etc. </p>
            <hr>
            <p class="sint">base_convert(numero,baseog,basetf)</p>
            <hr>
            <p class="ins">Insira o número</p>
        </div>
    </main>
</body>
</html>